# Live Sound Console – Android app

WebView wrapper that bundles your HTML (app/src/main/assets/index.html). Landscape, fullscreen, keeps screen on, microphone/camera permission prompts supported.

## Get the APK
**Option A – GitHub (no install):** create a new GitHub repo, upload this folder's contents, open the Actions tab > "Build APK" > Run workflow. Download `LiveSoundConsole-apk` > app-debug.apk, copy to phone, install (allow "unknown sources").

**Option B – Android Studio:** File > Open this folder > Build > Build APK(s).

Note: Google Fonts load online; offline the app falls back to system fonts.


## v1.1 changes
- index.html updated to the latest console (amp rack, Control Room, BOSS delay pedal, media fixes) with the logo/favicon.
- Launcher icon redrawn to match the logo.
- Wrapper code unchanged. If you installed an earlier APK, uninstall it first (each GitHub build is signed with a different debug key).
- Upload the folder contents INCLUDING the hidden .github folder, otherwise the Build APK action will not appear.
