# Live Sound Console – Android app

WebView wrapper that bundles your HTML (app/src/main/assets/index.html). Landscape, fullscreen, keeps screen on, microphone/camera permission prompts supported.

## Get the APK
**Option A – GitHub (no install):** create a new GitHub repo, upload this folder's contents, open the Actions tab > "Build APK" > Run workflow. Download `LiveSoundConsole-apk` > app-debug.apk, copy to phone, install (allow "unknown sources").

**Option B – Android Studio:** File > Open this folder > Build > Build APK(s).

Note: Google Fonts load online; offline the app falls back to system fonts.


## v1.2 changes
- **File picker fixed:** Android's stock picker only allowed the first accepted type (audio), so videos were greyed out. MainActivity now opens the picker for audio AND video, with multi-select.
- **YouTube fallback:** if the stage player is refused (Error 153 etc.) the app opens the video in a built-in YouTube player (Close button, back button closes it). Also available any time with the "Open link" button. Note: volume then follows YouTube's own controls, not the mixer.
- **Diagnostics:** tap the logo 5 times to show/hide an on-screen log (picker events, YouTube answers, errors). Send me a screenshot of it if something still fails.
- Links that would leave the app open in the in-app YouTube player or the phone's browser instead of replacing the app.
- Page: latest console (amp rack, Control Room, BOSS pedal) + logo. Launcher icon redrawn.

Install: uninstall the old app first (each GitHub build is signed with a different debug key).
Upload the folder contents INCLUDING the hidden .github folder so the Build APK action appears.
