LIVE SOUND CONSOLE - BUILD AN APK
=================================
Contents
  www/index.html            the app (single file, everything inside)
  www/manifest.webmanifest  app name + icons
  www/icon-192.png, icon-512.png
  resources/                icon.png (512), adaptive icon foreground/background (1024)
  capacitor.config.json     Capacitor settings (https scheme - needed so YouTube plays)
  package.json

IMPORTANT - why the "https" setting matters
  YouTube refuses to play inside pages loaded from file:// (Error 153).
  Capacitor with androidScheme "https" serves the app from https://localhost,
  so YouTube works. Wrappers that load file:///android_asset/... will show
  the Error 153 again.

OPTION A - Online converter (easiest, but YouTube may fail)
  Upload the zip to a site such as WebIntoApp / Appsgeyser / GoNative.
  If YouTube shows Error 153, use Option B or C instead.

OPTION B - Capacitor + Android Studio (recommended)
  Needs: Node.js 18+, Android Studio, JDK 17.
  1. unzip this folder, open a terminal inside it
  2. npm install
  3. npx cap add android
  4. npx cap sync android
  5. Open android/app/src/main/AndroidManifest.xml and add, above <application>:
       <uses-permission android:name="android.permission.RECORD_AUDIO" />
       <uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />
  6. npx cap open android   -> Android Studio opens
  7. Build > Build Bundle(s)/APK(s) > Build APK(s)
     (Debug APK: android/app/build/outputs/apk/debug/app-debug.apk)
  Icon: Android Studio > right-click res > New > Image Asset, pick resources/icon.png

OPTION C - Host the page, wrap the web address (YouTube + mic work)
  1. Upload www/ to a free HTTPS host (Netlify Drop, GitHub Pages).
  2. In any "website to APK" tool enter that https:// address.

Microphone: the first time you tap Live Mic, Android asks permission - tap Allow.
Local audio/video files: use "Choose audio or video files" inside the app.
