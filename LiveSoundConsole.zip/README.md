# Live Sound Console - Android

1. Upload everything in this folder to the ROOT of your GitHub repo
   (the `.github/workflows/Build.yml` file must keep that exact path).
2. Open the **Actions** tab -> the "Build APK" run.
3. When it is green, scroll to **Artifacts** and download `LiveSoundConsole-APK`.
4. Unzip, install `app-debug.apk` on your phone (allow "install unknown apps").

The web page lives in `app/src/main/assets/index.html`. Replace that file to update the app.
The app serves it from an https origin, so YouTube links play (no Error 153).
